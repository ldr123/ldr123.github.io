#include "il2cpp-config.h"
#include "IOSelector.h"

namespace il2cpp
{
namespace icalls
{
namespace System
{
namespace System
{
    void IOSelector::Add(intptr_t handle, Il2CppObject* job)
    {
        IL2CPP_NOT_IMPLEMENTED_ICALL(IOSelector::Add);
        IL2CPP_UNREACHABLE;
    }

    void IOSelector::Remove(intptr_t handle)
    {
        IL2CPP_NOT_IMPLEMENTED_ICALL(IOSelector::Remove);
        IL2CPP_UNREACHABLE;
    }
} // namespace System
} // namespace System
} // namespace icalls
} // namespace il2cpp
