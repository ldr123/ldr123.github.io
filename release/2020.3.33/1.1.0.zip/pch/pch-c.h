#pragma once

#include "il2cpp-config.h"
#include "il2cpp-object-internals.h"
#include "il2cpp-class-internals.h"

#if defined(_MSC_VER)
#include <intrin.h>
#endif

#include <string.h>
#include <stdio.h>
#include <assert.h>
