#pragma once

namespace il2cpp
{
namespace os
{
    class LastError
    {
    public:
        static uint32_t GetLastError();
    };
} /* namespace os */
} /* namespace il2cpp*/
