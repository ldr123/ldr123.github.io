#pragma once

#include "il2cpp-config.h"
#include "Baselib.h"
#include "Cpp/ReentrantLock.h"

namespace il2cpp
{
namespace vm
{
    extern baselib::ReentrantLock g_MetadataLock;
} // namespace vm
} // namespace il2cpp
