#pragma once

#include "il2cpp-config.h"
struct Il2CppString;

namespace il2cpp
{
namespace icalls
{
namespace System
{
namespace System
{
namespace Configuration
{
    class LIBIL2CPP_CODEGEN_API InternalConfigurationHost
    {
    public:
        static Il2CppString* get_bundled_machine_config();
    };
} /* namespace Configuration */
} /* namespace System */
} /* namespace System */
} /* namespace icalls */
} /* namespace il2cpp */
