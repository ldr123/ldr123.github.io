#include "HuatuoConfig.h"

namespace huatuo
{
	HuatuoConfig HuatuoConfig::_ins;

}