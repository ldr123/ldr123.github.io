#include "il2cpp-config.h"

#if IL2CPP_DEBUG
void il2cpp_assert(const char* assertion, const char* file, unsigned int line);
#endif
