#pragma once
#include <vector>

struct Il2CppType;

namespace il2cpp
{
namespace metadata
{
    typedef std::vector<const Il2CppType*> Il2CppTypeVector;
} /* namespace vm */
} /* namespace il2cpp */
