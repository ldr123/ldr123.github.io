#pragma once
#include "il2cpp-config.h"

#ifdef __cplusplus

#include <string>

typedef std::basic_string<Il2CppChar> UTF16String;
typedef std::basic_string<Il2CppNativeChar> Il2CppNativeString;

#endif
