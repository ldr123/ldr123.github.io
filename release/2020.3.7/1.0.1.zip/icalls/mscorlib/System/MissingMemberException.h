#pragma once

namespace il2cpp
{
namespace icalls
{
namespace mscorlib
{
namespace System
{
    class LIBIL2CPP_CODEGEN_API MissingMemberException
    {
    public:
        static Il2CppString* FormatSignature(Il2CppArray* signature);
    };
} // namespace System
} // namespace mscorlib
} // namespace icalls
} // namespace il2cpp
