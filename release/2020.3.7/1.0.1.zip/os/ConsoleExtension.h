#pragma once

#include "il2cpp-config.h"

#if IL2CPP_SUPPORTS_CONSOLE_EXTENSION

#include <string>
#include <stdint.h>

namespace il2cpp
{
namespace os
{
namespace ConsoleExtension
{
    void Write(const char* buffer);
}
}
}

#endif
