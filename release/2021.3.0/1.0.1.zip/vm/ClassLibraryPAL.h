#pragma once

#include "il2cpp-config.h"

namespace il2cpp
{
namespace vm
{
    class ClassLibraryPAL
    {
    public:
        static void Initialize();
    };
} // namespace vm
} // namepsace il2cpp
