#include "il2cpp-config.h"

#if IL2CPP_USE_GENERIC_FILE
#include "os/File.h"

namespace il2cpp
{
namespace os
{
    bool File::Truncate(FileHandle* handle, int *error)
    {
        NO_UNUSED_WARNING(handle);
        NO_UNUSED_WARNING(error);
        return false;
    }
}
}
#endif
